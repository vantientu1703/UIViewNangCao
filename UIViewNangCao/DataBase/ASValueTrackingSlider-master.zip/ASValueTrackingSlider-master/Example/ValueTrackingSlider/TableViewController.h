//
//  TableViewController.h
//  ValueTrackingSlider
//
//  Created by Alan Skipp on 07/04/2014.
//  Copyright (c) 2014 Alan Skipp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UIView *headerView;
@end
